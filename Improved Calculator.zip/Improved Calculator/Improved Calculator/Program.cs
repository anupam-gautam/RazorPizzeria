﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Improved_Calculator
{
    internal class Program
    {
        static void Main(string[] args)
        {

            //To avoid the user to give string/invalid character in the menu 
            try
            {
                //Asking user for the type of Calculation
                Console.WriteLine("Press 1 for simple arithmetics operation");
                Console.WriteLine("Press 2 to find the values of angles in triginometry");
                int inputChoice = Convert.ToInt16(Console.ReadLine());


                //Implementing a switch case to call the right method of calculation
                switch (inputChoice)
                {
                    //basic calulator
                    case 1:
                        NormalCalculator.calculate();
                        break;

                    //trigonmetry calculator
                    case 2:
                        TrigValueCalculator.calculate();
                        break;

                    default:
                        Console.WriteLine("Choice " + inputChoice + " not present in the menu");
                        break;

                }
            }
            catch(Exception ex)
            {
                Console.WriteLine("Error"+ex.Message);
            }
            


            
            
            Console.ReadLine();

            
        }
    }
}
