﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Improved_Calculator
{
    internal class TrigValueCalculator
    {
        public static void calculate()
        {
            try
            {
                Console.Write("\nGive the value of angle: ");
                double angle = Convert.ToDouble(Console.ReadLine());
                double radian = angle * Math.PI / 180;
                Console.WriteLine("Value of sine" + angle + " is: " + Math.Round(radian, 2));
            }

            catch (Exception ex)
            {
                Console.WriteLine("Error"+ex.Message);
            }
            
        }
        

    }
}
