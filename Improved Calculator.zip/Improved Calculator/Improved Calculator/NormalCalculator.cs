﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Improved_Calculator
{
    internal class NormalCalculator
    {
        public static void calculate()
        {
            try
            {
                Console.WriteLine("\nChoose your operation: \n1.Addition\n2.Subtraction\n3.Multiplication\n4.Division" +
                    "\n5.Modulus");
                int inputChoice = Convert.ToInt32(Console.ReadLine());
                Console.Write("Number 1: ");
                double num1 = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Number 2: ");
                double num2 = Convert.ToDouble(Console.ReadLine());

                switch (inputChoice)
                {
                    case 1:
                        Console.WriteLine("Ans: "+ (num1 + num2));
                        break;
                    case 2:
                        Console.WriteLine("Ans: " + (num1 - num2));
                        break;
                    case 3:
                        Console.WriteLine("Ans: " + (num1 * num2));
                        break;
                    case 4:
                        Console.WriteLine("Quotient: " + (num1 / num2) + "Remainder: "+ (num1%num2));
                        break;
                    case 5:
                        Console.WriteLine("Ans: " + (num1 % num2));
                        break;
                    default:
                        Console.WriteLine("Wrong value");
                        break;


                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
